<?php
    //Muhammad Aditio Kamal Ibrahim
    //aditiokamal@gmail.com
    //pure function
    function penjumlahan($bil1, $bil2)
    {
        $tambah = $bil1 + $bil2;
        return $tambah;

    }
    echo "hasil penjumlahan adalah : " . penjumlahan(2, 3) . "<br>";
?>