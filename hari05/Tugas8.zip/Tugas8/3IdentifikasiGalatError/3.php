<?php
//Muhammad Aditio Kamal Ibrahim
//aditiokamal@gmail.com
    echo "Hello World";
    $x = "Selamat Datang";
    $y = 5;

    echo "<br>";
    echo $x;
    echo "<br>";
    echo "Saya sedang belajar Web Developer ";
    echo "<br>";
    echo $x;
    echo "<br>";
    echo "Ini angka ". $y;
?>